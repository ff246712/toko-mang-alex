let total = 0;

function tambahKeranjang(nama, harga) {
  const keranjang = document.getElementById("keranjang");
  const item = document.createElement("li");
  item.innerText = `${nama} - Rp${harga.toLocaleString("id-ID")}`;
  keranjang.appendChild(item);

  total += harga;
  document.getElementById("total").innerText = total.toLocaleString("id-ID");
}
